import React from 'react';
import { AppView } from '../types';
import { Wallet, ChevronDown, CheckCircle2, Trophy, HelpCircle, Layers } from 'lucide-react';

interface NavbarProps {
  currentView: AppView;
  onSelectView: (view: AppView) => void;
  walletAddress: string | null;
  onOpenWalletModal: () => void;
  onOpenHowItWorks: () => void;
  onOpenLeaderboard: () => void;
  isDarkTheme?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onSelectView,
  walletAddress,
  onOpenWalletModal,
  onOpenHowItWorks,
  onOpenLeaderboard,
  isDarkTheme = false,
}) => {
  const pages: { id: AppView; label: string; num: string }[] = [
    { id: 'home', label: 'Homepage / Hero', num: '1' },
    { id: 'pools', label: 'Pools Overview', num: '2' },
    { id: 'predict', label: 'Make a Prediction', num: '3' },
    { id: 'live', label: 'Live Pool Details', num: '4' },
    { id: 'results', label: 'Results & Claim', num: '5' },
  ];

  const navClasses = isDarkTheme
    ? 'border-neutral-800 bg-[#0A0E14]/80 text-white'
    : 'border-neutral-200/80 bg-white/80 text-neutral-900';

  return (
    <header className={`sticky top-0 z-40 backdrop-blur-md border-b transition-colors duration-200 ${navClasses}`}>
      {/* Top Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-8">
          <button
            id="brand-logo-btn"
            onClick={() => onSelectView('home')}
            className="flex items-center gap-2 group cursor-pointer focus:outline-none"
          >
            <span className="text-xl font-black tracking-[0.25em] uppercase hover:opacity-80 transition-opacity">
              EXTREMA
            </span>
          </button>

          {/* Primary Nav Links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
            <button
              id="nav-play-btn"
              onClick={() => onSelectView('pools')}
              className={`hover:opacity-75 transition-opacity pb-0.5 ${
                currentView === 'pools' || currentView === 'predict'
                  ? 'border-b-2 border-current font-semibold'
                  : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              Play
            </button>
            <button
              id="nav-pools-btn"
              onClick={() => onSelectView('pools')}
              className={`hover:opacity-75 transition-opacity pb-0.5 ${
                currentView === 'pools'
                  ? 'border-b-2 border-current font-semibold'
                  : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              Pools
            </button>
            <button
              id="nav-leaderboard-btn"
              onClick={onOpenLeaderboard}
              className="text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-opacity flex items-center gap-1.5"
            >
              <Trophy className="w-3.5 h-3.5 opacity-70" />
              Leaderboard
            </button>
            <button
              id="nav-how-it-works-btn"
              onClick={onOpenHowItWorks}
              className="text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-opacity flex items-center gap-1.5"
            >
              <HelpCircle className="w-3.5 h-3.5 opacity-70" />
              How it works
            </button>
          </nav>
        </div>

        {/* Right Section: Wallet & Actions */}
        <div className="flex items-center gap-3">
          {walletAddress ? (
            <button
              id="connected-wallet-btn"
              onClick={onOpenWalletModal}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border transition-all shadow-sm ${
                isDarkTheme
                  ? 'bg-neutral-900/90 border-neutral-700 text-neutral-100 hover:bg-neutral-800'
                  : 'bg-neutral-100 border-neutral-200 text-neutral-800 hover:bg-neutral-200/80'
              }`}
            >
              <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-400 to-indigo-500 flex items-center justify-center text-[10px] text-white font-bold shadow-inner">
                0x
              </div>
              <span className="font-mono">{walletAddress}</span>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </button>
          ) : (
            <button
              id="connect-wallet-btn"
              onClick={onOpenWalletModal}
              className="flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold bg-neutral-900 text-white hover:bg-neutral-800 transition-colors shadow-sm"
            >
              <Wallet className="w-3.5 h-3.5" />
              Connect Wallet
            </button>
          )}
        </div>
      </div>

      {/* Pages Switcher Bar matching the 5 screens in user prompt */}
      <div className={`border-t py-2 px-4 ${isDarkTheme ? 'border-neutral-800 bg-[#070A0F]' : 'border-neutral-100 bg-neutral-50/90'}`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto no-scrollbar gap-2">
          <div className="flex items-center gap-1.5 shrink-0 text-xs font-semibold text-neutral-400 uppercase tracking-wider pl-1 pr-2">
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Pages:</span>
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
            {pages.map((p) => {
              const isActive = currentView === p.id;
              return (
                <button
                  key={p.id}
                  id={`page-switch-${p.id}`}
                  onClick={() => onSelectView(p.id)}
                  className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                    isActive
                      ? isDarkTheme
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                        : 'bg-neutral-900 text-white shadow-sm'
                      : isDarkTheme
                      ? 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
                      : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200/70'
                  }`}
                >
                  <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                    isActive
                      ? isDarkTheme ? 'bg-cyan-400 text-black' : 'bg-white text-neutral-900'
                      : isDarkTheme ? 'bg-neutral-800 text-neutral-400' : 'bg-neutral-200 text-neutral-600'
                  }`}>
                    {p.num}
                  </span>
                  <span>{p.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </header>
  );
};
