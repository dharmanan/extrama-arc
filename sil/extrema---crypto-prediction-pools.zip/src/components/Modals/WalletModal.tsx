import React from 'react';
import { X, Wallet, Copy, Check, Plus, ExternalLink, ShieldCheck } from 'lucide-react';
import { PredictionTicket } from '../../types';

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  address: string;
  balanceUsdc: number;
  onAddFunds: (amount: number) => void;
  onDisconnect: () => void;
  tickets: PredictionTicket[];
}

export const WalletModal: React.FC<WalletModalProps> = ({
  isOpen,
  onClose,
  address,
  balanceUsdc,
  onAddFunds,
  onDisconnect,
  tickets,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard?.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        id="wallet-modal-content"
        className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-7 shadow-2xl border border-neutral-200 relative animate-in fade-in zoom-in-95 duration-150"
      >
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-1.5 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-indigo-600 flex items-center justify-center text-white shadow-md">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-neutral-950">Connected Wallet</h3>
            <p className="text-xs text-neutral-500">Arc Network Testnet</p>
          </div>
        </div>

        {/* Address Card */}
        <div className="bg-neutral-50 rounded-2xl p-4 border border-neutral-200/80 mb-5 flex items-center justify-between">
          <div>
            <div className="text-[11px] text-neutral-400 font-medium">Account</div>
            <div className="text-xs font-mono font-bold text-neutral-900 mt-0.5">
              {address}
            </div>
          </div>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 text-xs font-medium text-neutral-600 hover:text-neutral-950 px-2.5 py-1.5 rounded-lg bg-white border border-neutral-200 shadow-2xs transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        {/* Balance Card */}
        <div className="bg-gradient-to-br from-neutral-900 to-neutral-800 text-white rounded-2xl p-5 mb-6 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-neutral-400 font-medium">Available Balance</span>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              Live Faucet
            </span>
          </div>
          <div className="text-3xl font-black font-mono tracking-tight text-white mb-4">
            ${balanceUsdc.toLocaleString()} <span className="text-sm font-semibold text-neutral-400">USDC</span>
          </div>

          <button
            id="faucet-add-funds-btn"
            onClick={() => onAddFunds(50)}
            className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold border border-white/15 flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Claim +50 Testnet USDC</span>
          </button>
        </div>

        {/* Prediction Tickets Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-xs font-bold text-neutral-700">Active Prediction Tickets</span>
            <span className="text-xs text-neutral-400 font-mono">({tickets.length})</span>
          </div>

          {tickets.length === 0 ? (
            <div className="bg-neutral-50 rounded-xl p-4 text-center text-xs text-neutral-400 border border-dashed border-neutral-200">
              No active tickets yet. Pick a pool to make your first prediction!
            </div>
          ) : (
            <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
              {tickets.map((t) => (
                <div
                  key={t.id}
                  className="bg-neutral-50 rounded-xl p-3 border border-neutral-200/80 flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="font-bold text-neutral-900">
                      {t.asset} {t.period} {t.direction}
                    </span>
                    <div className="text-[11px] text-neutral-500 font-mono">
                      Target: ${t.predictedPrice.toFixed(2)}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center gap-1 text-[10px] font-mono text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                      NFT #{t.nftTokenId}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-neutral-100">
          <button
            onClick={onDisconnect}
            className="text-xs text-red-600 hover:text-red-700 font-medium cursor-pointer"
          >
            Disconnect Wallet
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-neutral-900 text-white text-xs font-semibold hover:bg-neutral-800 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
