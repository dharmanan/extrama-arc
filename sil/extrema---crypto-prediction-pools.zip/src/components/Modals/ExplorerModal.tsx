import React from 'react';
import { X, ExternalLink, CheckCircle2, Copy, Check } from 'lucide-react';

interface ExplorerModalProps {
  isOpen: boolean;
  onClose: () => void;
  txHash?: string;
}

export const ExplorerModal: React.FC<ExplorerModalProps> = ({
  isOpen,
  onClose,
  txHash = '0x8f3c72b19e4a5d89201f1984c39de592bc70932e650893a2083b9281a97d91e4',
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard?.writeText(txHash);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-neutral-200 relative animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-1.5 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <ExternalLink className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold tracking-tight text-neutral-950 font-display">
              Arc Explorer
            </h3>
            <p className="text-xs text-neutral-500">Transaction & Contract Verification</p>
          </div>
        </div>

        <div className="space-y-3.5 text-xs mb-6">
          <div className="bg-neutral-50 rounded-2xl p-4 border border-neutral-200/80">
            <div className="text-[11px] text-neutral-400 font-medium mb-1">Transaction Hash</div>
            <div className="flex items-center justify-between gap-2">
              <span className="font-mono text-neutral-900 break-all font-semibold">
                {txHash}
              </span>
              <button
                onClick={handleCopy}
                className="shrink-0 p-1.5 rounded-lg bg-white border border-neutral-200 text-neutral-600 hover:text-neutral-950"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-neutral-50 rounded-2xl p-3.5 border border-neutral-200/80">
              <div className="text-[11px] text-neutral-400 font-medium">Status</div>
              <div className="flex items-center gap-1.5 text-emerald-600 font-bold mt-0.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Success / Finalized</span>
              </div>
            </div>

            <div className="bg-neutral-50 rounded-2xl p-3.5 border border-neutral-200/80">
              <div className="text-[11px] text-neutral-400 font-medium">Block Height</div>
              <div className="font-mono font-bold text-neutral-900 mt-0.5">#14,928,502</div>
            </div>
          </div>

          <div className="bg-neutral-50 rounded-2xl p-3.5 border border-neutral-200/80">
            <div className="text-[11px] text-neutral-400 font-medium">Verified Contract</div>
            <div className="font-mono text-neutral-800 mt-0.5">
              ExtremaPredictionPools.sol (ERC-721 + Chainlink/Binance Feed)
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-3 border-t border-neutral-100">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-neutral-900 text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
