import React from 'react';
import { X, Target, Ticket, LineChart, Award } from 'lucide-react';

interface HowItWorksModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartPlaying: () => void;
}

export const HowItWorksModal: React.FC<HowItWorksModalProps> = ({
  isOpen,
  onClose,
  onStartPlaying,
}) => {
  if (!isOpen) return null;

  const steps = [
    {
      icon: <Target className="w-5 h-5 text-amber-500" />,
      title: '1. Select Asset & Direction',
      description:
        'Choose BTC, ETH, SOL, or HYPE. Select a timeframe (Daily, Weekly, or Quarterly) and whether you are predicting the high peak or low floor price.',
    },
    {
      icon: <Ticket className="w-5 h-5 text-indigo-500" />,
      title: '2. Mint Your Prediction Ticket',
      description:
        'Pay exactly 1 USDC. Each price prediction is minted as an exclusive ERC-721 NFT ticket. No duplicate prices are allowed in a single pool.',
    },
    {
      icon: <LineChart className="w-5 h-5 text-emerald-500" />,
      title: '3. Oracle Settlement',
      description:
        'When the round clock reaches zero, verifiable Binance Futures Mark Price feeds record the absolute extreme price (high or low) reached during the period.',
    },
    {
      icon: <Award className="w-5 h-5 text-purple-500" />,
      title: '4. Closest Wins the Pool',
      description:
        'The 3 players with the smallest absolute difference (Δ) win the entire pool: 1st gets 60%, 2nd gets 25%, and 3rd gets 15%. Claim rewards with your NFT ticket.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-neutral-200 relative animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-1.5 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="mb-6">
          <h3 className="text-2xl font-bold tracking-tight text-neutral-950 font-display">
            How EXTREMA Works
          </h3>
          <p className="text-xs text-neutral-500 mt-1">
            Real prices. Real players. Transparent pool dynamics.
          </p>
        </div>

        <div className="space-y-4 mb-8">
          {steps.map((step, idx) => (
            <div key={idx} className="flex items-start gap-4 p-3 rounded-2xl hover:bg-neutral-50 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-neutral-100 flex items-center justify-center shrink-0">
                {step.icon}
              </div>
              <div>
                <h4 className="text-sm font-bold text-neutral-900">{step.title}</h4>
                <p className="text-xs text-neutral-600 mt-1 leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-neutral-600 hover:text-neutral-900 cursor-pointer"
          >
            Close
          </button>
          <button
            onClick={() => {
              onClose();
              onStartPlaying();
            }}
            className="px-6 py-2.5 rounded-xl bg-neutral-950 text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            Start Playing
          </button>
        </div>
      </div>
    </div>
  );
};
