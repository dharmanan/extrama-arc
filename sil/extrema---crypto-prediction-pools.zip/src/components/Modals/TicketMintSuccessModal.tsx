import React from 'react';
import { X, CheckCircle, ArrowRight, ShieldCheck, Ticket } from 'lucide-react';
import { PredictionTicket } from '../../types';

interface TicketMintSuccessModalProps {
  ticket: PredictionTicket | null;
  isOpen: boolean;
  onClose: () => void;
  onViewLivePool: () => void;
}

export const TicketMintSuccessModal: React.FC<TicketMintSuccessModalProps> = ({
  ticket,
  isOpen,
  onClose,
  onViewLivePool,
}) => {
  if (!isOpen || !ticket) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-sm w-full p-6 sm:p-7 shadow-2xl border border-neutral-200 relative animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-1.5 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Success Icon */}
        <div className="text-center mb-5">
          <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-3">
            <CheckCircle className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-neutral-950">Prediction Minted!</h3>
          <p className="text-xs text-neutral-500 mt-0.5">
            Your NFT ticket is live on Arc blockchain
          </p>
        </div>

        {/* NFT Ticket Physical Styled Card */}
        <div className="bg-gradient-to-br from-neutral-950 via-neutral-900 to-indigo-950 text-white rounded-2xl p-5 border border-neutral-700 shadow-xl relative overflow-hidden mb-6">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-xl pointer-events-none" />

          {/* Top Ticket Header */}
          <div className="flex items-center justify-between pb-3 border-b border-white/10 text-xs">
            <span className="font-bold tracking-widest text-neutral-400 uppercase">EXTREMA PASS</span>
            <span className="font-mono text-indigo-400 font-bold">#{ticket.nftTokenId}</span>
          </div>

          {/* Middle details */}
          <div className="py-4 space-y-2">
            <div className="text-[11px] text-neutral-400">Target Asset & Direction</div>
            <div className="text-lg font-bold">
              {ticket.asset} · {ticket.period} {ticket.direction}
            </div>

            <div className="pt-2">
              <div className="text-[11px] text-neutral-400">Locked In Prediction</div>
              <div className="text-2xl font-mono font-black text-amber-400">
                ${ticket.predictedPrice.toFixed(2)}
              </div>
            </div>
          </div>

          {/* Simulated Barcode */}
          <div className="pt-3 border-t border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-0.5 opacity-60">
              <div className="w-1 h-5 bg-white" />
              <div className="w-0.5 h-5 bg-white" />
              <div className="w-2 h-5 bg-white" />
              <div className="w-0.5 h-5 bg-white" />
              <div className="w-1.5 h-5 bg-white" />
              <div className="w-1 h-5 bg-white" />
              <div className="w-0.5 h-5 bg-white" />
              <div className="w-2.5 h-5 bg-white" />
              <div className="w-1 h-5 bg-white" />
            </div>
            <div className="text-[10px] font-mono text-neutral-400">1 USDC ENTRY</div>
          </div>
        </div>

        {/* Buttons */}
        <div className="space-y-2.5">
          <button
            onClick={() => {
              onClose();
              onViewLivePool();
            }}
            className="w-full py-3.5 rounded-xl bg-neutral-950 text-white text-xs font-semibold hover:bg-neutral-800 transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
          >
            <span>View Live Pool Details</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onClose}
            className="w-full py-2 text-xs font-medium text-neutral-500 hover:text-neutral-900 cursor-pointer"
          >
            Keep Browsing Pools
          </button>
        </div>
      </div>
    </div>
  );
};
