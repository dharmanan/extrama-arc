import React from 'react';
import { X, Trophy, Medal, Award, Flame } from 'lucide-react';

interface LeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const topPlayers = [
    { rank: 1, address: '0x7a8...3f1e', wins: 24, winRate: '68%', earningsUsdc: 38400, avatar: '🦊' },
    { rank: 2, address: '0x9cD...8A21', wins: 19, winRate: '59%', earningsUsdc: 24150, avatar: '🐱' },
    { rank: 3, address: '0x4eF...7D2c', wins: 15, winRate: '54%', earningsUsdc: 18900, avatar: '🐼' },
    { rank: 4, address: '0x12a...B881', wins: 12, winRate: '48%', earningsUsdc: 14200, avatar: '🦁' },
    { rank: 5, address: '0x88c...E910', wins: 10, winRate: '45%', earningsUsdc: 11500, avatar: '🐺' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-neutral-200 relative animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-1.5 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center shadow-xs">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold tracking-tight text-neutral-950 font-display">
              Global Leaderboard
            </h3>
            <p className="text-xs text-neutral-500">
              Top predictors ranked by cumulative USDC prize winnings
            </p>
          </div>
        </div>

        {/* Players List */}
        <div className="space-y-2.5 mb-6">
          {topPlayers.map((player) => (
            <div
              key={player.rank}
              className="flex items-center justify-between p-3 rounded-2xl bg-neutral-50 border border-neutral-100 hover:bg-neutral-100/70 transition-colors"
            >
              <div className="flex items-center gap-3">
                <span className={`w-6 text-center text-xs font-bold ${
                  player.rank === 1 ? 'text-amber-500 font-extrabold' : player.rank === 2 ? 'text-neutral-400' : 'text-neutral-600'
                }`}>
                  #{player.rank}
                </span>
                <span className="text-base">{player.avatar}</span>
                <div>
                  <div className="text-xs font-mono font-bold text-neutral-900">{player.address}</div>
                  <div className="text-[10px] text-neutral-400">
                    {player.wins} wins · {player.winRate} win rate
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs font-bold font-mono text-neutral-950">
                  ${player.earningsUsdc.toLocaleString()} USDC
                </div>
                <div className="text-[10px] text-emerald-600 font-semibold flex items-center justify-end gap-1">
                  <Flame className="w-3 h-3" />
                  Top Predictor
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end pt-3 border-t border-neutral-100">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-neutral-900 text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
