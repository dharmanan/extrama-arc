import React, { useState, useEffect } from 'react';
import { Pool } from '../../types';
import { SOL_HISTOGRAM_DATA } from '../../mockData';
import { ExternalLink, Clock, Users, DollarSign, ArrowDown, ArrowUp, Sparkles, ArrowRight } from 'lucide-react';

interface LivePoolDetailsViewProps {
  pool?: Pool;
  userPrediction?: number;
  onGoToResults: () => void;
  onOpenExplorer: () => void;
}

export const LivePoolDetailsView: React.FC<LivePoolDetailsViewProps> = ({
  pool,
  userPrediction = 268.50,
  onGoToResults,
  onOpenExplorer,
}) => {
  // Live ticking countdown
  const [timeLeft, setTimeLeft] = useState({ hours: 12, minutes: 28, seconds: 16 });
  const [hoveredBar, setHoveredBar] = useState<{ price: string; count: number; range: string } | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: 59, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const format2 = (n: number) => n.toString().padStart(2, '0');

  // Find max count for scaling histogram
  const maxCount = Math.max(...SOL_HISTOGRAM_DATA.map((d) => d.count));

  return (
    <div className="min-h-[calc(100vh-6.5rem)] bg-[#070A0F] text-white py-8 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Cosmic Atmosphere matching screenshot */}
      <div className="absolute top-0 right-0 w-[550px] h-[550px] pointer-events-none opacity-30">
        {/* Planet sphere glow */}
        <div className="absolute top-[-100px] right-[-80px] w-96 h-96 rounded-full bg-gradient-to-br from-cyan-500 via-teal-900 to-transparent blur-2xl" />
        <svg viewBox="0 0 400 400" className="w-full h-full opacity-40">
          <circle cx="350" cy="80" r="160" fill="none" stroke="#06B6D4" strokeWidth="1" strokeDasharray="4 6" />
          <circle cx="350" cy="80" r="210" fill="none" stroke="#14F195" strokeWidth="0.5" />
        </svg>
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header Section */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            {/* Solana Gradient Logo */}
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#9945FF] via-[#14F195] to-[#00C2FF] p-0.5 shadow-lg shadow-cyan-500/20">
              <div className="w-full h-full rounded-[14px] bg-[#0A0E17] flex flex-col items-center justify-center gap-1 p-2">
                <div className="w-full h-[2px] bg-gradient-to-r from-[#9945FF] to-[#14F195] rounded-full" />
                <div className="w-full h-[2px] bg-gradient-to-r from-[#14F195] to-[#00C2FF] rounded-full" />
                <div className="w-full h-[2px] bg-gradient-to-r from-[#00C2FF] to-[#9945FF] rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
                  <span>SOL</span>
                  <span className="text-neutral-600 font-light">|</span>
                  <span className="text-neutral-200">Daily High</span>
                </h1>
              </div>
              <div className="flex items-center gap-2 text-xs text-neutral-400 mt-1">
                <span>Round ends in</span>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-cyan-950/60 border border-cyan-800/50 text-cyan-300 font-mono font-medium text-xs">
                  <Clock className="w-3 h-3 text-cyan-400" />
                  <span>
                    {timeLeft.hours}h {format2(timeLeft.minutes)}m {format2(timeLeft.seconds)}s
                  </span>
                </span>
              </div>
            </div>
          </div>

          {/* Quick shortcut to Results page */}
          <div className="flex items-center gap-3">
            <button
              id="view-results-shortcut-btn"
              onClick={onGoToResults}
              className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-semibold text-neutral-300 hover:text-white transition-all flex items-center gap-2 cursor-pointer shadow-xs"
            >
              <span>View Settled Round Example</span>
              <ArrowRight className="w-3.5 h-3.5 text-cyan-400" />
            </button>
          </div>
        </div>

        {/* Top 4 Metrics Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-[#0E131F]/90 border border-neutral-800/90 rounded-2xl p-4 sm:p-5">
            <div className="text-2xl sm:text-3xl font-bold text-white font-mono tracking-tight">
              876
            </div>
            <div className="text-xs text-neutral-400 font-medium mt-1">Players</div>
          </div>

          <div className="bg-[#0E131F]/90 border border-neutral-800/90 rounded-2xl p-4 sm:p-5">
            <div className="text-2xl sm:text-3xl font-bold text-white font-mono tracking-tight">
              876 USDC
            </div>
            <div className="text-xs text-neutral-400 font-medium mt-1">Pool Size</div>
          </div>

          <div className="bg-[#0E131F]/90 border border-neutral-800/90 rounded-2xl p-4 sm:p-5">
            <div className="text-2xl sm:text-3xl font-bold text-neutral-200 font-mono tracking-tight">
              $231.40
            </div>
            <div className="text-xs text-neutral-400 font-medium mt-1">Lowest Prediction</div>
          </div>

          <div className="bg-[#0E131F]/90 border border-neutral-800/90 rounded-2xl p-4 sm:p-5">
            <div className="text-2xl sm:text-3xl font-bold text-neutral-200 font-mono tracking-tight">
              $298.75
            </div>
            <div className="text-xs text-neutral-400 font-medium mt-1">Highest Prediction</div>
          </div>
        </div>

        {/* Main Content: Interactive Distribution Chart & Sidebar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Chart area (8 cols) */}
          <div className="lg:col-span-8 bg-[#0C101A] border border-neutral-800/80 rounded-3xl p-6 sm:p-7">
            {/* User Prediction Floating Marker & Info */}
            <div className="relative pt-8 pb-4">
              {/* Floating Pill for 'Your prediction $268.50' matching reference */}
              <div className="relative flex justify-center mb-2">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#102C2E] border border-[#14F195]/40 text-[#14F195] text-xs font-semibold shadow-lg shadow-emerald-950/40">
                  <span className="w-2 h-2 rounded-full bg-[#14F195] animate-pulse"></span>
                  <span>Your prediction</span>
                  <span className="font-mono font-bold">${userPrediction.toFixed(2)}</span>
                </div>
              </div>

              {/* Interactive Bar Histogram Container */}
              <div className="h-64 sm:h-72 w-full flex items-end justify-between gap-1 sm:gap-1.5 pt-4 pb-2 border-b border-neutral-800 relative">
                {SOL_HISTOGRAM_DATA.map((item, index) => {
                  const heightPercent = Math.max(8, (item.count / maxCount) * 100);
                  const isUserTarget = item.isUser;

                  return (
                    <div
                      key={index}
                      onMouseEnter={() => setHoveredBar(item)}
                      onMouseLeave={() => setHoveredBar(null)}
                      className="relative flex-1 flex flex-col items-center justify-end h-full group cursor-pointer"
                    >
                      {/* Bar column */}
                      <div
                        style={{ height: `${heightPercent}%` }}
                        className={`w-full rounded-t-sm transition-all duration-300 ${
                          isUserTarget
                            ? 'bg-gradient-to-t from-[#0E7490] to-[#14F195] shadow-[0_0_15px_rgba(20,241,149,0.5)]'
                            : 'bg-gradient-to-t from-[#0F3A47] to-[#155E75] group-hover:from-[#155E75] group-hover:to-[#06B6D4]'
                        }`}
                      />

                      {/* Tooltip on hover */}
                      <div className="opacity-0 group-hover:opacity-100 pointer-events-none absolute -top-12 z-30 transition-opacity bg-neutral-900 border border-neutral-700 px-2.5 py-1 rounded text-[10px] text-white whitespace-nowrap shadow-md">
                        <div className="font-bold text-cyan-300">{item.range}</div>
                        <div>{item.count} tickets</div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* X-Axis Price Markers matching image ($220, $240, $260, $280, $300, $320) */}
              <div className="flex justify-between items-center text-xs text-neutral-400 font-mono mt-3 px-1">
                <span>$220</span>
                <span>$240</span>
                <span>$260</span>
                <span>$280</span>
                <span>$300</span>
                <span>$320</span>
              </div>

              {/* Legend matching screenshot */}
              <div className="flex items-center gap-6 mt-6 text-xs text-neutral-400">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#155E75]" />
                  <span>Prediction distribution</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#14F195]" />
                  <span className="text-neutral-300">Your prediction</span>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar: Pool Info (4 cols) */}
          <div className="lg:col-span-4 bg-[#0C101A] border border-neutral-800/80 rounded-3xl p-6 sm:p-7 space-y-6">
            <h2 className="text-base font-bold tracking-wide text-white">
              Pool Info
            </h2>

            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between pb-2.5 border-b border-neutral-800/60">
                <span className="text-neutral-400">Asset</span>
                <span className="font-semibold text-white font-mono">SOL</span>
              </div>

              <div className="flex items-center justify-between pb-2.5 border-b border-neutral-800/60">
                <span className="text-neutral-400">Market</span>
                <span className="font-semibold text-white">Daily High</span>
              </div>

              <div className="flex items-center justify-between pb-2.5 border-b border-neutral-800/60">
                <span className="text-neutral-400">Round</span>
                <span className="font-semibold text-white font-mono">#4821</span>
              </div>

              <div className="flex items-center justify-between pb-2.5 border-b border-neutral-800/60">
                <span className="text-neutral-400">Period</span>
                <span className="font-semibold text-white">Oct 6, 2025</span>
              </div>

              <div className="flex flex-col gap-1 pb-2.5 border-b border-neutral-800/60">
                <span className="text-neutral-400">Price Source</span>
                <span className="font-medium text-neutral-200">
                  Binance Futures (SOLUSDT Mark Price)
                </span>
              </div>

              <div className="flex items-center justify-between pb-2.5 border-b border-neutral-800/60">
                <span className="text-neutral-400">Entry Fee</span>
                <span className="font-semibold text-white font-mono">1 USDC</span>
              </div>

              <div className="flex items-center justify-between pb-2.5 border-b border-neutral-800/60">
                <span className="text-neutral-400">Players</span>
                <span className="font-semibold text-white font-mono">876</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Pool Size</span>
                <span className="font-semibold text-cyan-400 font-mono">876 USDC</span>
              </div>
            </div>

            {/* View on Explorer Button */}
            <div className="pt-2">
              <button
                id="live-view-explorer-btn"
                onClick={onOpenExplorer}
                className="w-full py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-xs font-semibold text-white transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>View on Explorer</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
