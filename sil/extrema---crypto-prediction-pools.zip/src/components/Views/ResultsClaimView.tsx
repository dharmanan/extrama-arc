import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, Trophy, ExternalLink, Sparkles } from 'lucide-react';
import { RESULTS_WINNERS, RESULTS_TIMELINE } from '../../mockData';
import confetti from 'canvas-confetti';

interface ResultsClaimViewProps {
  onBackToPools: () => void;
  onOpenExplorer: () => void;
  onClaimSuccess: (amount: number) => void;
}

export const ResultsClaimView: React.FC<ResultsClaimViewProps> = ({
  onBackToPools,
  onOpenExplorer,
  onClaimSuccess,
}) => {
  const [claimed, setClaimed] = useState<boolean>(false);
  const [isClaiming, setIsClaiming] = useState<boolean>(false);

  const handleClaim = () => {
    if (claimed) return;
    setIsClaiming(true);

    setTimeout(() => {
      setIsClaiming(false);
      setClaimed(true);

      // Trigger celebratory confetti
      confetti({
        particleCount: 90,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#F59E0B', '#10B981', '#6366F1', '#EC4899'],
      });

      onClaimSuccess(5400);
    }, 700);
  };

  // SVG dimensions for price timeline
  const svgWidth = 540;
  const svgHeight = 180;
  // Map timeline data to curve coordinates
  // Range: 2070 to 2210
  const minP = 2070;
  const maxP = 2210;
  const rangeP = maxP - minP;

  const points = RESULTS_TIMELINE.map((item, idx) => {
    const x = 30 + (idx / (RESULTS_TIMELINE.length - 1)) * (svgWidth - 60);
    const y = svgHeight - 35 - ((item.price - minP) / rangeP) * (svgHeight - 65);
    return { ...item, x, y };
  });

  // Create smooth bezier path
  let pathD = `M ${points[0].x} ${points[0].y}`;
  for (let i = 0; i < points.length - 1; i++) {
    const curr = points[i];
    const next = points[i + 1];
    const mx = (curr.x + next.x) / 2;
    pathD += ` C ${mx} ${curr.y}, ${mx} ${next.y}, ${next.x} ${next.y}`;
  }

  const fillD = `${pathD} L ${points[points.length - 1].x} ${svgHeight - 20} L ${points[0].x} ${svgHeight - 20} Z`;

  // Find lowest point for highlight marker
  const lowPoint = points.find((p) => p.isFinalLow) || points[3];

  return (
    <div className="min-h-[calc(100vh-6.5rem)] bg-[#F8F8FA] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Back link */}
        <div className="mb-6">
          <button
            id="results-back-btn"
            onClick={onBackToPools}
            className="inline-flex items-center gap-2 text-xs font-semibold text-neutral-600 hover:text-neutral-900 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Pools</span>
          </button>
        </div>

        {/* Two Column Layout matching reference image 5 */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Round Complete Celebration & Timeline Chart (7 cols) */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-7 sm:p-8 border border-neutral-200/80 shadow-xs relative overflow-hidden">
            {/* Festive micro decorations */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h1 className="text-3xl sm:text-4xl font-black text-neutral-950 tracking-tight">
                    Round Complete!
                  </h1>
                  <span className="text-2xl animate-bounce">🎉</span>
                </div>
                <p className="text-xs sm:text-sm text-neutral-500 font-medium">
                  ETH Weekly Low | Oct 6 - Oct 12, 2025
                </p>
              </div>
            </div>

            {/* Final Price Box */}
            <div className="pt-2 pb-6">
              <div className="text-xs text-neutral-400 font-semibold uppercase tracking-wider mb-1">
                Final Price
              </div>
              <div className="flex items-center gap-3">
                <span className="text-4xl sm:text-5xl font-black font-mono tracking-tight text-neutral-950">
                  $2,086.43
                </span>
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Verified
                </span>
              </div>
            </div>

            {/* Price Timeline Chart */}
            <div className="relative pt-6 pb-2">
              {/* Floating Pill Marker above Final Low */}
              <div
                style={{
                  left: `${(lowPoint.x / svgWidth) * 100}%`,
                  top: '12px',
                }}
                className="absolute -translate-x-1/2 z-20"
              >
                <div className="bg-white border-2 border-purple-400 shadow-md px-3 py-1.5 rounded-xl text-center">
                  <div className="text-xs font-bold text-neutral-950 font-mono">
                    $2,086.43
                  </div>
                  <div className="text-[10px] text-purple-600 font-semibold">
                    Final Low
                  </div>
                </div>
                <div className="w-[1px] h-8 bg-purple-400 mx-auto border-dashed border-l" />
              </div>

              {/* SVG Curve */}
              <div className="w-full overflow-hidden">
                <svg
                  viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                  className="w-full h-auto overflow-visible"
                >
                  <defs>
                    <linearGradient id="purpleGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="rgba(168, 85, 247, 0.25)" />
                      <stop offset="100%" stopColor="rgba(168, 85, 247, 0.01)" />
                    </linearGradient>
                  </defs>

                  {/* Filled area */}
                  <path d={fillD} fill="url(#purpleGrad)" />

                  {/* Line */}
                  <path
                    d={pathD}
                    fill="none"
                    stroke="#A855F7"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />

                  {/* Low point marker circle */}
                  <circle
                    cx={lowPoint.x}
                    cy={lowPoint.y}
                    r="5.5"
                    fill="#A855F7"
                    stroke="#FFFFFF"
                    strokeWidth="2"
                  />
                  <circle
                    cx={lowPoint.x}
                    cy={lowPoint.y}
                    r="9"
                    fill="none"
                    stroke="#A855F7"
                    strokeWidth="1.5"
                    opacity="0.5"
                  />
                </svg>
              </div>

              {/* X Axis Dates matching image */}
              <div className="flex justify-between items-center text-xs text-neutral-400 font-medium mt-1 px-4">
                <span>Oct 6</span>
                <span>Oct 8</span>
                <span>Oct 10</span>
                <span>Oct 12</span>
              </div>
            </div>

            {/* Bottom tagline matching screenshot */}
            <div className="mt-8 pt-4 border-t border-neutral-100 flex items-center gap-2 text-xs text-neutral-400">
              <span className="text-neutral-300">📊</span>
              <span>More rounds. More opportunities.</span>
            </div>
          </div>

          {/* Right Column: Winners & Claim (5 cols) */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-7 border border-neutral-200/80 shadow-xs relative">
            {/* Header & Handwritten note */}
            <div className="flex items-start justify-between mb-6">
              <h2 className="text-xl font-bold text-neutral-950 tracking-tight">
                Winners
              </h2>
              {/* Handwritten text matching screenshot */}
              <p className="font-handwriting text-2xl text-neutral-600 rotate-[-5deg] select-none">
                Good calls everyone.
              </p>
            </div>

            {/* Winners List */}
            <div className="space-y-4 mb-8">
              {RESULTS_WINNERS.map((winner) => {
                const trophyColor =
                  winner.rank === 1
                    ? 'text-amber-500'
                    : winner.rank === 2
                    ? 'text-neutral-400'
                    : 'text-amber-700';

                return (
                  <div
                    key={winner.rank}
                    id={`winner-card-${winner.rank}`}
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-neutral-50/80 border border-neutral-100 hover:bg-neutral-50 transition-colors"
                  >
                    {/* Rank & Avatar & Address */}
                    <div className="flex items-center gap-3">
                      <div className={`shrink-0 ${trophyColor}`}>
                        <Trophy className="w-5 h-5" />
                      </div>

                      {/* Custom User Avatar */}
                      <div className={`w-9 h-9 rounded-full ${winner.avatarBg} flex items-center justify-center text-xs font-bold shadow-xs border border-white`}>
                        {winner.rank === 1 ? '🦊' : winner.rank === 2 ? '🐱' : '🐼'}
                      </div>

                      <div>
                        <div className="text-xs font-mono font-bold text-neutral-900">
                          {winner.address}
                        </div>
                        <div className="text-[11px] text-neutral-500 font-mono">
                          ${winner.predictedPrice.toFixed(2)}{' '}
                          <span className="text-neutral-400">
                            (Δ ${winner.delta.toFixed(2)})
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Prize USDC & Percentage */}
                    <div className="text-right">
                      <div className="text-sm font-bold text-neutral-950 font-mono">
                        {winner.prizeUsdc.toLocaleString()} USDC
                      </div>
                      <div className="text-[11px] font-semibold text-amber-600">
                        {winner.prizePercentage}% of pool
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Claim Action Button */}
            <div className="space-y-3">
              <button
                id="claim-reward-btn"
                onClick={handleClaim}
                disabled={claimed || isClaiming}
                className={`w-full py-4 rounded-2xl font-semibold text-sm transition-all shadow-md flex items-center justify-center gap-2.5 cursor-pointer ${
                  claimed
                    ? 'bg-emerald-600 text-white shadow-emerald-600/20'
                    : 'bg-neutral-950 text-white hover:bg-neutral-800 shadow-neutral-900/10'
                }`}
              >
                {claimed ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Reward Claimed! (+5,400 USDC)</span>
                  </>
                ) : isClaiming ? (
                  <span>Verifying NFT Ticket...</span>
                ) : (
                  <>
                    <span>Claim with NFT</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <p className="text-[11px] text-neutral-400 text-center">
                Winners can claim their rewards using their NFT tickets.
              </p>

              <div className="pt-2 text-center">
                <button
                  id="results-explorer-link"
                  onClick={onOpenExplorer}
                  className="inline-flex items-center gap-1.5 text-xs text-neutral-500 hover:text-neutral-900 font-medium cursor-pointer"
                >
                  <span>View on Explorer</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
