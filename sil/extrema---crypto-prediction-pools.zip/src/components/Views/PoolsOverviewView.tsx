import React, { useState } from 'react';
import { Pool, AssetSymbol, PoolPeriod } from '../../types';
import { Sparkline } from '../Sparkline';
import { ArrowRight, ArrowUpRight, ArrowDownRight, Sun, TrendingUp, TrendingDown } from 'lucide-react';

interface PoolsOverviewViewProps {
  pools: Pool[];
  selectedAsset: AssetSymbol;
  onSelectAsset: (asset: AssetSymbol) => void;
  onSelectPool: (pool: Pool) => void;
}

export const PoolsOverviewView: React.FC<PoolsOverviewViewProps> = ({
  pools,
  selectedAsset,
  onSelectAsset,
  onSelectPool,
}) => {
  const [selectedPeriod, setSelectedPeriod] = useState<PoolPeriod>('Daily');
  const [showAllPools, setShowAllPools] = useState<boolean>(false);

  const assets: AssetSymbol[] = ['BTC', 'ETH', 'SOL', 'HYPE'];
  const periods: PoolPeriod[] = ['Daily', 'Weekly', 'Quarterly'];

  // Filter pools based on asset or show all if expanded
  const filteredPools = pools.filter((p) => {
    if (showAllPools) return true;
    return p.asset === selectedAsset;
  });

  const getDirectionIcon = (direction: 'High' | 'Low', color: string) => {
    if (direction === 'High') {
      if (color === 'orange') {
        return (
          <div className="w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
            <Sun className="w-3.5 h-3.5" />
          </div>
        );
      }
      return (
        <div className="w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center text-purple-600">
          <ArrowUpRight className="w-3.5 h-3.5" />
        </div>
      );
    } else {
      if (color === 'blue') {
        return (
          <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
            <ArrowDownRight className="w-3.5 h-3.5" />
          </div>
        );
      }
      return (
        <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
          <TrendingDown className="w-3.5 h-3.5" />
        </div>
      );
    }
  };

  const getCardHeaderColor = (color: string) => {
    switch (color) {
      case 'orange':
        return 'text-amber-700';
      case 'blue':
        return 'text-blue-700';
      case 'purple':
        return 'text-purple-700';
      case 'green':
        return 'text-emerald-700';
      default:
        return 'text-neutral-700';
    }
  };

  return (
    <div className="min-h-[calc(100vh-6.5rem)] bg-[#F8F8FA] py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header Section */}
        <div className="mb-8">
          <h1 className="font-display text-4xl sm:text-5xl text-neutral-950 font-normal tracking-tight mb-2">
            Active Pools
          </h1>
          <p className="text-neutral-600 text-sm sm:text-base">
            Pick an asset, a time period, and predict the high or low.
          </p>
        </div>

        {/* Filter Controls Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          {/* Asset Pills */}
          <div className="flex items-center gap-2">
            {assets.map((asset) => {
              const isActive = selectedAsset === asset && !showAllPools;
              return (
                <button
                  key={asset}
                  id={`filter-asset-${asset}`}
                  onClick={() => {
                    setShowAllPools(false);
                    onSelectAsset(asset);
                  }}
                  className={`px-4 py-2 rounded-full text-xs font-bold tracking-wider transition-all cursor-pointer ${
                    isActive
                      ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/30 ring-2 ring-amber-500/20'
                      : 'bg-white text-neutral-700 border border-neutral-200/80 hover:bg-neutral-50 hover:border-neutral-300'
                  }`}
                >
                  {asset}
                </button>
              );
            })}
          </div>

          {/* Period Selector Tabs */}
          <div className="inline-flex p-1 bg-neutral-200/70 rounded-full border border-neutral-300/40 text-xs font-medium self-start sm:self-auto">
            {periods.map((period) => {
              const isActive = selectedPeriod === period;
              return (
                <button
                  key={period}
                  id={`filter-period-${period}`}
                  onClick={() => setSelectedPeriod(period)}
                  className={`px-3.5 py-1.5 rounded-full transition-all cursor-pointer ${
                    isActive
                      ? 'bg-white text-neutral-900 font-semibold shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  {period}
                </button>
              );
            })}
          </div>
        </div>

        {/* Pools 2x2 Grid matching reference */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-8">
          {filteredPools.map((pool) => {
            return (
              <div
                key={pool.id}
                id={`pool-card-${pool.id}`}
                onClick={() => onSelectPool(pool)}
                className="group bg-white rounded-2xl p-6 border border-neutral-200/80 shadow-[0_2px_8px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_20px_rgba(0,0,0,0.06)] hover:border-neutral-300 transition-all duration-200 cursor-pointer flex flex-col justify-between"
              >
                {/* Card Header Tag */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    {getDirectionIcon(pool.direction, pool.color)}
                    <span className={`text-xs font-bold tracking-wide ${getCardHeaderColor(pool.color)}`}>
                      {pool.title}
                    </span>
                  </div>
                </div>

                {/* Price Display */}
                <div className="mb-4">
                  <div className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-950 font-mono">
                    {pool.formattedCurrentPrice}
                  </div>
                  <div className="text-xs text-neutral-400 font-medium mt-0.5">
                    Current Price
                  </div>
                </div>

                {/* Metrics and Action Row */}
                <div className="flex items-end justify-between pt-2">
                  <div className="flex items-center gap-6">
                    <div>
                      <div className="text-sm font-semibold text-neutral-900">
                        {pool.playersCount.toLocaleString()}
                      </div>
                      <div className="text-[11px] text-neutral-400 font-medium">
                        Players
                      </div>
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-neutral-900">
                        ${pool.poolSizeUsdc.toLocaleString()}
                      </div>
                      <div className="text-[11px] text-neutral-400 font-medium">
                        Pool Size
                      </div>
                    </div>
                  </div>

                  {/* Circular Arrow Button */}
                  <div className="w-10 h-10 rounded-full border border-neutral-200 flex items-center justify-center text-neutral-600 group-hover:bg-neutral-950 group-hover:text-white group-hover:border-neutral-950 transition-colors shadow-xs">
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </div>

                {/* Bottom Sparkline Graph */}
                <div className="mt-4 pt-2">
                  <Sparkline data={pool.sparklineData} color={pool.color} height={36} />
                </div>
              </div>
            );
          })}
        </div>

        {/* View All Pools Footer Link */}
        <div className="text-center pt-2">
          <button
            id="view-all-pools-btn"
            onClick={() => setShowAllPools(!showAllPools)}
            className="inline-flex items-center gap-2 text-xs font-bold text-neutral-800 hover:text-neutral-950 px-5 py-2.5 rounded-full border border-neutral-300 hover:border-neutral-400 bg-white shadow-xs transition-colors cursor-pointer"
          >
            <span>{showAllPools ? 'Show Filtered Assets' : 'View All Pools (24)'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
