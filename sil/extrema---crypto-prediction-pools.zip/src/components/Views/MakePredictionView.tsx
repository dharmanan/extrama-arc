import React, { useState } from 'react';
import { Pool, PredictionTicket } from '../../types';
import { ArrowLeft, ArrowRight, ShieldCheck, ChevronUp, ChevronDown, Check, Loader2 } from 'lucide-react';

interface MakePredictionViewProps {
  pool: Pool;
  onBack: () => void;
  onSubmitPrediction: (prediction: number) => void;
  walletConnected: boolean;
  onConnectWallet: () => void;
}

export const MakePredictionView: React.FC<MakePredictionViewProps> = ({
  pool,
  onBack,
  onSubmitPrediction,
  walletConnected,
  onConnectWallet,
}) => {
  // Default prediction based on ETH weekly low (2085.00) or pool's suggested
  const [predictionValue, setPredictionValue] = useState<number>(
    pool.asset === 'ETH' ? 2085.0 : pool.suggestedPredictions[1] || pool.currentPrice
  );
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const suggestedOptions =
    pool.asset === 'ETH'
      ? [2084.50, 2085.01, 2086.50, 2088.00]
      : pool.suggestedPredictions;

  const handleStep = (delta: number) => {
    setPredictionValue((prev) => +(prev + delta).toFixed(2));
  };

  const handleConfirm = () => {
    if (!walletConnected) {
      onConnectWallet();
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      onSubmitPrediction(predictionValue);
    }, 900);
  };

  return (
    <div className="min-h-[calc(100vh-6.5rem)] bg-[#F8F8FA] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Back navigation */}
        <div className="mb-6">
          <button
            id="predict-back-btn"
            onClick={onBack}
            className="inline-flex items-center gap-2 text-xs font-semibold text-neutral-600 hover:text-neutral-900 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>
        </div>

        {/* Hero Asset Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-neutral-200/80 shadow-[0_2px_12px_rgba(0,0,0,0.04)] mb-8 relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute right-0 top-0 w-96 h-96 bg-gradient-to-br from-indigo-100/40 via-purple-50/20 to-transparent rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            {/* Left Info */}
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-600/30 shrink-0">
                <svg viewBox="0 0 256 417" className="w-7 h-7 fill-white" xmlns="http://www.w3.org/2000/svg">
                  <path fill="#fff" fillOpacity="0.8" d="M127.961 0l-2.795 9.5v275.668l2.795 2.79 127.962-75.638z"/>
                  <path fill="#fff" d="M127.962 0L0 212.32l127.962 75.639V0z"/>
                  <path fill="#fff" fillOpacity="0.6" d="M127.961 312.187l-1.575 1.92v98.199l1.575 4.601 128.038-180.32z"/>
                  <path fill="#fff" fillOpacity="0.8" d="M127.962 416.905v-104.72L0 236.585z"/>
                </svg>
              </div>

              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-950 flex items-center gap-3">
                  <span>{pool.asset}</span>
                  <span className="text-neutral-300 font-light">|</span>
                  <span className="font-medium text-neutral-800">{pool.period} {pool.direction}</span>
                </h1>
                <p className="text-sm text-neutral-500 mt-1">
                  Predict the {pool.direction.toLowerCase()}est price of {pool.asset} during this {pool.period.toLowerCase()}.
                </p>
              </div>
            </div>

            {/* Right: 3D Crystal Graphic & Current Price */}
            <div className="flex items-center gap-6 self-end md:self-auto">
              <div className="hidden sm:block relative w-16 h-20">
                {/* 3D Geometric Polygonal Crystal SVG matching image */}
                <svg viewBox="0 0 100 120" className="w-full h-full drop-shadow-md">
                  <polygon points="50,5 90,45 50,75 10,45" fill="#E2E8F0" />
                  <polygon points="50,5 90,45 50,50" fill="#CBD5E1" />
                  <polygon points="50,5 10,45 50,50" fill="#F1F5F9" />
                  <polygon points="50,75 90,45 50,115" fill="#94A3B8" />
                  <polygon points="50,75 10,45 50,115" fill="#64748B" />
                </svg>
              </div>

              <div className="text-right">
                <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
                  Current Price
                </div>
                <div className="text-2xl sm:text-3xl font-bold font-mono text-neutral-950">
                  {pool.formattedCurrentPrice}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Prediction Form & Pool Details Split Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Form & Stepper (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-7 border border-neutral-200/80 shadow-xs">
              <label className="block text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2">
                Your Prediction (USD)
              </label>

              {/* Big Stepper Input Box matching screenshot */}
              <div className="relative flex items-center bg-neutral-50 border-2 border-neutral-200/80 rounded-2xl p-2 focus-within:border-neutral-900 focus-within:bg-white transition-all">
                <input
                  id="prediction-input"
                  type="number"
                  step="0.01"
                  value={predictionValue}
                  onChange={(e) => setPredictionValue(parseFloat(e.target.value) || 0)}
                  className="w-full bg-transparent px-4 py-3 text-3xl sm:text-4xl font-mono font-bold text-neutral-950 focus:outline-none"
                />

                {/* Vertical Stepper Controls */}
                <div className="flex flex-col gap-1 pr-2">
                  <button
                    id="stepper-up-btn"
                    onClick={() => handleStep(1)}
                    className="p-1.5 rounded-lg bg-white border border-neutral-200 text-neutral-600 hover:text-neutral-950 hover:bg-neutral-100 transition-colors cursor-pointer"
                    title="Increment"
                  >
                    <ChevronUp className="w-4 h-4" />
                  </button>
                  <button
                    id="stepper-down-btn"
                    onClick={() => handleStep(-1)}
                    className="p-1.5 rounded-lg bg-white border border-neutral-200 text-neutral-600 hover:text-neutral-950 hover:bg-neutral-100 transition-colors cursor-pointer"
                    title="Decrement"
                  >
                    <ChevronDown className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="text-xs text-neutral-400 font-medium mt-2 px-1">
                ≈ 1 USDC entry fee
              </div>

              {/* Suggested (nearby available) chips */}
              <div className="mt-6">
                <div className="text-xs font-semibold text-neutral-500 mb-2.5">
                  Suggested (nearby available)
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {suggestedOptions.map((val) => {
                    const isSelected = Math.abs(predictionValue - val) < 0.001;
                    return (
                      <button
                        key={val}
                        id={`suggested-chip-${val}`}
                        onClick={() => setPredictionValue(val)}
                        className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-medium transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-neutral-900 text-white shadow-xs'
                            : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200 border border-neutral-200/60'
                        }`}
                      >
                        {val.toFixed(2)}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Confirm Prediction CTA Button */}
              <div className="mt-8">
                <button
                  id="confirm-prediction-btn"
                  onClick={handleConfirm}
                  disabled={isSubmitting}
                  className="w-full py-4 rounded-2xl bg-neutral-950 text-white font-semibold text-sm hover:bg-neutral-800 transition-all shadow-md shadow-neutral-950/10 flex items-center justify-center gap-3 cursor-pointer disabled:opacity-75"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Minting Prediction Ticket...</span>
                    </>
                  ) : (
                    <>
                      <span>Confirm Prediction · 1 USDC</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

              {/* Micro note */}
              <div className="mt-4 flex items-center justify-center gap-2 text-[11px] text-neutral-400 text-center">
                <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
                <span>Each prediction mints a unique NFT ticket. Same price cannot be taken twice.</span>
              </div>
            </div>
          </div>

          {/* Right Column: Pool Specs & Artwork backdrop (5 cols) */}
          <div className="lg:col-span-5 relative rounded-3xl overflow-hidden bg-[#E7E5DF] p-7 border border-neutral-300/80 min-h-[380px] flex flex-col justify-between">
            {/* Mountain silhouette background */}
            <div className="absolute inset-0 pointer-events-none opacity-40">
              <svg viewBox="0 0 500 400" className="w-full h-full object-cover">
                <polygon points="50,400 250,150 400,320 500,200 500,400" fill="#475569" />
                <polygon points="150,400 320,80 480,400" fill="#1E293B" opacity="0.6" />
              </svg>
            </div>

            {/* Specifications list */}
            <div className="relative z-10 space-y-5 bg-white/70 backdrop-blur-sm rounded-2xl p-5 border border-white/60">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-200/60">
                <span className="text-xs font-semibold text-neutral-500">Entry Fee</span>
                <span className="text-sm font-bold text-neutral-950 font-mono">1 USDC</span>
              </div>

              <div className="flex items-center justify-between pb-3 border-b border-neutral-200/60">
                <span className="text-xs font-semibold text-neutral-500">Round Ends</span>
                <span className="text-xs font-bold text-neutral-950">Sun, Oct 12 23:59 UTC</span>
              </div>

              <div className="flex flex-col gap-1">
                <span className="text-xs font-semibold text-neutral-500">Price Source</span>
                <span className="text-xs font-bold text-neutral-950">
                  {pool.priceSource}
                </span>
              </div>
            </div>

            {/* Handwritten Quote matching reference image */}
            <div className="relative z-10 text-right pt-8">
              <p className="font-handwriting text-3xl text-neutral-800 rotate-[-4deg] drop-shadow-xs">
                Same Market.<br />
                New Perspectives.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
