import React from 'react';
import { AssetSymbol } from '../../types';
import { AssetBadge } from '../AssetBadge';
import { ArrowRight, Sparkles, ShieldCheck } from 'lucide-react';

interface HomepageViewProps {
  onStartPlaying: () => void;
  onSelectAsset: (asset: AssetSymbol) => void;
}

export const HomepageView: React.FC<HomepageViewProps> = ({
  onStartPlaying,
  onSelectAsset,
}) => {
  const assets: AssetSymbol[] = ['BTC', 'ETH', 'SOL', 'HYPE'];

  return (
    <div className="relative min-h-[calc(100vh-6.5rem)] bg-[#ECEBE7] overflow-hidden flex flex-col justify-between">
      {/* Background Mountain Graphics & Sky Atmosphere */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        {/* Sky gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#F5F4F0] via-[#E8E6DF] to-[#D5D2C7] opacity-90" />
        
        {/* Subtle cloud wash */}
        <div className="absolute top-0 right-0 w-3/4 h-full bg-gradient-to-l from-transparent via-white/10 to-transparent blur-3xl" />

        {/* Scenic Mountain SVG Backdrop on the right side matching reference */}
        <svg
          className="absolute bottom-0 right-0 w-full lg:w-[62%] h-[68%] lg:h-[88%] object-cover object-bottom opacity-85 select-none"
          viewBox="0 0 1000 800"
          preserveAspectRatio="xMidYMax slice"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="skyGlow" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFF7ED" stopOpacity="0.8" />
              <stop offset="60%" stopColor="#FED7AA" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#CBD5E1" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="mountainFar" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#64748B" />
              <stop offset="50%" stopColor="#475569" />
              <stop offset="100%" stopColor="#334155" />
            </linearGradient>
            <linearGradient id="mountainMid" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#F1F5F9" />
              <stop offset="25%" stopColor="#94A3B8" />
              <stop offset="70%" stopColor="#334155" />
              <stop offset="100%" stopColor="#1E293B" />
            </linearGradient>
            <linearGradient id="mountainNear" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#E2E8F0" />
              <stop offset="20%" stopColor="#64748B" />
              <stop offset="80%" stopColor="#0F172A" />
            </linearGradient>
          </defs>

          {/* Far peaks */}
          <polygon points="200,800 450,320 600,520 800,280 1000,800" fill="url(#mountainFar)" opacity="0.6" />
          
          {/* Main jagged snow peak */}
          <polygon points="350,800 580,180 720,410 890,260 1000,800" fill="url(#mountainMid)" />
          {/* Snow cap highlights */}
          <polygon points="580,180 540,245 560,265 580,240 605,270 625,235" fill="#FFFFFF" opacity="0.9" />
          <polygon points="890,260 860,310 880,330 910,295" fill="#FFFFFF" opacity="0.9" />

          {/* Foreground rocky ridge */}
          <polygon points="480,800 680,360 820,540 1000,430 1000,800" fill="url(#mountainNear)" />
          <polygon points="680,360 650,420 670,440 690,410 710,430" fill="#F8FAFC" opacity="0.8" />

          {/* Atmospheric cloud mist overlay */}
          <ellipse cx="650" cy="500" rx="300" ry="80" fill="#FFFFFF" opacity="0.18" />
          <ellipse cx="800" cy="420" rx="250" ry="60" fill="#FFFFFF" opacity="0.15" />
        </svg>

        {/* Handwritten text overlay as seen in screenshot */}
        <div className="absolute right-8 md:right-16 lg:right-24 bottom-24 md:bottom-28 z-10 select-none text-right">
          <p className="font-handwriting text-3xl md:text-5xl text-white/95 drop-shadow-[0_2px_8px_rgba(0,0,0,0.5)] rotate-[-3deg] leading-tight">
            Different outlooks.<br />
            A brighter tomorrow.
          </p>
        </div>
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 md:pt-20 pb-12 w-full flex-1 flex flex-col justify-between">
        <div className="max-w-xl lg:max-w-2xl">
          {/* Eyebrow */}
          <div className="flex items-center gap-2 mb-6">
            <span className="text-xs font-bold tracking-[0.2em] text-neutral-500 uppercase">
              REAL PRICES. REAL PLAYERS.
            </span>
          </div>

          {/* Main Display Headline */}
          <h1 className="font-display text-6xl sm:text-7xl md:text-8xl tracking-tight text-neutral-950 font-normal leading-[0.95] mb-6">
            Predict<br />
            what’s next.
          </h1>

          {/* Subtext */}
          <p className="text-base sm:text-lg text-neutral-700 max-w-lg leading-relaxed mb-8 font-normal">
            1 USDC. Four assets. Daily, weekly or quarterly.<br />
            Closest predictions win the pool.
          </p>

          {/* CTA Button */}
          <div className="flex flex-wrap items-center gap-4 mb-12">
            <button
              id="hero-start-playing-btn"
              onClick={onStartPlaying}
              className="inline-flex items-center gap-3 px-7 py-3.5 rounded-full bg-neutral-950 text-white font-medium text-sm hover:bg-neutral-800 transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-neutral-900/15 group cursor-pointer"
            >
              <span>Start Playing</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* 4 Asset Selectors */}
          <div className="pt-2 pb-8">
            <div className="flex items-center gap-4 sm:gap-6">
              {assets.map((asset) => (
                <button
                  key={asset}
                  id={`hero-asset-${asset}`}
                  onClick={() => onSelectAsset(asset)}
                  className="group flex flex-col items-center gap-2 cursor-pointer transition-transform hover:-translate-y-1 focus:outline-none"
                >
                  <div className="transition-transform group-hover:scale-105">
                    <AssetBadge asset={asset} size="lg" />
                  </div>
                  <span className="text-xs font-bold tracking-wider text-neutral-700 group-hover:text-neutral-950 transition-colors">
                    {asset}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Metrics and Platform Trust Bar */}
        <div className="pt-8 border-t border-neutral-300/60 flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          {/* Numeric stats */}
          <div className="flex items-center gap-8 md:gap-14">
            <div>
              <div className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-950">
                24
              </div>
              <div className="text-xs font-medium text-neutral-500 mt-0.5">
                Active Pools
              </div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-950">
                12,438
              </div>
              <div className="text-xs font-medium text-neutral-500 mt-0.5">
                Players
              </div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-950">
                $12,438
              </div>
              <div className="text-xs font-medium text-neutral-500 mt-0.5">
                Total Volume
              </div>
            </div>
          </div>

          {/* Built on Arc & Powered by USDC */}
          <div className="flex items-center gap-5 text-xs text-neutral-600 font-medium">
            <div className="flex items-center gap-1.5">
              <span className="text-neutral-500">Built on</span>
              <span className="inline-flex items-center gap-1 font-semibold text-neutral-800">
                <span className="w-3.5 h-3.5 rounded-full bg-indigo-600 inline-block"></span>
                Arc
              </span>
            </div>
            <span className="text-neutral-400">·</span>
            <div className="flex items-center gap-1.5">
              <span className="text-neutral-500">Powered by</span>
              <span className="inline-flex items-center gap-1 font-semibold text-neutral-800">
                <span className="w-3.5 h-3.5 rounded-full bg-[#2775CA] text-white flex items-center justify-center text-[8px] font-bold">
                  $
                </span>
                USDC
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
