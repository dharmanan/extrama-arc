import React from 'react';

interface SparklineProps {
  data: number[];
  color: 'orange' | 'blue' | 'purple' | 'green' | 'cyan';
  height?: number;
  width?: number;
  showFill?: boolean;
}

export const Sparkline: React.FC<SparklineProps> = ({
  data,
  color,
  height = 40,
  width = 160,
  showFill = true,
}) => {
  if (!data || data.length < 2) return null;

  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;

  const paddingY = 4;
  const usableHeight = height - paddingY * 2;

  // Calculate coordinates
  const points = data.map((val, idx) => {
    const x = (idx / (data.length - 1)) * width;
    const y = height - paddingY - ((val - min) / range) * usableHeight;
    return { x, y };
  });

  // Generate smooth SVG curve using cubic bezier
  let pathD = `M ${points[0].x} ${points[0].y}`;
  for (let i = 0; i < points.length - 1; i++) {
    const current = points[i];
    const next = points[i + 1];
    const controlX = (current.x + next.x) / 2;
    pathD += ` C ${controlX} ${current.y}, ${controlX} ${next.y}, ${next.x} ${next.y}`;
  }

  const fillD = `${pathD} L ${width} ${height} L 0 ${height} Z`;

  const colorMap = {
    orange: {
      stroke: '#F97316',
      fillStart: 'rgba(249, 115, 22, 0.25)',
      fillEnd: 'rgba(249, 115, 22, 0.01)',
    },
    blue: {
      stroke: '#3B82F6',
      fillStart: 'rgba(59, 130, 246, 0.25)',
      fillEnd: 'rgba(59, 130, 246, 0.01)',
    },
    purple: {
      stroke: '#A855F7',
      fillStart: 'rgba(168, 85, 247, 0.25)',
      fillEnd: 'rgba(168, 85, 247, 0.01)',
    },
    green: {
      stroke: '#10B981',
      fillStart: 'rgba(16, 185, 129, 0.25)',
      fillEnd: 'rgba(16, 185, 129, 0.01)',
    },
    cyan: {
      stroke: '#06B6D4',
      fillStart: 'rgba(6, 182, 212, 0.25)',
      fillEnd: 'rgba(6, 182, 212, 0.01)',
    },
  };

  const scheme = colorMap[color] || colorMap.orange;
  const gradientId = `spark-grad-${color}-${Math.random().toString(36).substring(2, 7)}`;

  return (
    <div className="w-full overflow-hidden flex items-end">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto overflow-visible"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id={gradientId} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={scheme.fillStart} />
            <stop offset="100%" stopColor={scheme.fillEnd} />
          </linearGradient>
        </defs>
        {showFill && <path d={fillD} fill={`url(#${gradientId})`} />}
        <path
          d={pathD}
          fill="none"
          stroke={scheme.stroke}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
};
