import React from 'react';
import { AssetSymbol } from '../types';

interface AssetBadgeProps {
  asset: AssetSymbol;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showLabel?: boolean;
}

export const AssetBadge: React.FC<AssetBadgeProps> = ({ asset, size = 'md', showLabel = false }) => {
  const sizeClasses = {
    sm: 'w-7 h-7 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-base font-bold',
    xl: 'w-20 h-20 text-xl font-bold',
  };

  const renderIcon = () => {
    switch (asset) {
      case 'BTC':
        return (
          <div className={`${sizeClasses[size]} rounded-full bg-[#F7931A] text-white flex items-center justify-center font-bold shadow-md shadow-amber-500/20`}>
            <span>₿</span>
          </div>
        );
      case 'ETH':
        return (
          <div className={`${sizeClasses[size]} rounded-full bg-[#3B4252] text-white flex items-center justify-center shadow-md shadow-indigo-900/20 relative overflow-hidden`}>
            {/* Ethereum Diamond SVG */}
            <svg viewBox="0 0 256 417" className="w-1/2 h-1/2 fill-white" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid">
              <path fill="#fff" fillOpacity="0.75" d="M127.961 0l-2.795 9.5v275.668l2.795 2.79 127.962-75.638z"/>
              <path fill="#fff" d="M127.962 0L0 212.32l127.962 75.639V0z"/>
              <path fill="#fff" fillOpacity="0.6" d="M127.961 312.187l-1.575 1.92v98.199l1.575 4.601 128.038-180.32z"/>
              <path fill="#fff" fillOpacity="0.8" d="M127.962 416.905v-104.72L0 236.585z"/>
            </svg>
          </div>
        );
      case 'SOL':
        return (
          <div className={`${sizeClasses[size]} rounded-full bg-gradient-to-tr from-[#9945FF] via-[#14F195] to-[#00C2FF] text-white flex items-center justify-center shadow-md shadow-emerald-500/20 p-1.5`}>
            <div className="w-full h-full rounded-full bg-black/80 flex flex-col items-center justify-center gap-0.5 p-1">
              <div className="w-3/4 h-[2px] bg-gradient-to-r from-[#9945FF] to-[#14F195] rounded-full"></div>
              <div className="w-3/4 h-[2px] bg-gradient-to-r from-[#14F195] to-[#00C2FF] rounded-full"></div>
              <div className="w-3/4 h-[2px] bg-gradient-to-r from-[#00C2FF] to-[#9945FF] rounded-full"></div>
            </div>
          </div>
        );
      case 'HYPE':
        return (
          <div className={`${sizeClasses[size]} rounded-full bg-[#111827] border border-emerald-500/40 text-[#14F195] flex items-center justify-center font-black tracking-tighter shadow-md`}>
            <span>H</span>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="inline-flex flex-col items-center gap-1.5">
      {renderIcon()}
      {showLabel && (
        <span className="text-xs font-semibold tracking-wider text-gray-700">{asset}</span>
      )}
    </div>
  );
};
