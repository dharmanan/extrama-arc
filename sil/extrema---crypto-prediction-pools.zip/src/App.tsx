import React, { useState } from 'react';
import { AppView, AssetSymbol, Pool, PredictionTicket } from './types';
import { INITIAL_POOLS } from './mockData';
import { Navbar } from './components/Navbar';
import { HomepageView } from './components/Views/HomepageView';
import { PoolsOverviewView } from './components/Views/PoolsOverviewView';
import { MakePredictionView } from './components/Views/MakePredictionView';
import { LivePoolDetailsView } from './components/Views/LivePoolDetailsView';
import { ResultsClaimView } from './components/Views/ResultsClaimView';

// Modals
import { WalletModal } from './components/Modals/WalletModal';
import { HowItWorksModal } from './components/Modals/HowItWorksModal';
import { LeaderboardModal } from './components/Modals/LeaderboardModal';
import { TicketMintSuccessModal } from './components/Modals/TicketMintSuccessModal';
import { ExplorerModal } from './components/Modals/ExplorerModal';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [selectedAsset, setSelectedAsset] = useState<AssetSymbol>('BTC');
  const [pools, setPools] = useState<Pool[]>(INITIAL_POOLS);
  
  // Default to ETH Weekly Low pool so View 3 matches screenshot 3
  const ethWeeklyLowPool = INITIAL_POOLS.find((p) => p.id === 'eth-weekly-low') || INITIAL_POOLS[0];
  const [selectedPool, setSelectedPool] = useState<Pool>(ethWeeklyLowPool);

  // Connected wallet matching reference screenshot (0x3af...92E1)
  const [walletAddress, setWalletAddress] = useState<string | null>('0x3af4...92E1');
  const [balanceUsdc, setBalanceUsdc] = useState<number>(340);
  const [userPrediction, setUserPrediction] = useState<number>(268.50);

  // User Tickets
  const [tickets, setTickets] = useState<PredictionTicket[]>([
    {
      id: 'ticket-init-1',
      poolId: 'sol-daily-high',
      asset: 'SOL',
      period: 'Daily',
      direction: 'High',
      predictedPrice: 268.50,
      entryFee: 1,
      createdAt: 'Today, 10:42 UTC',
      nftTokenId: '4821-876',
      txHash: '0x32a8...f901',
    },
  ]);
  const [latestMintedTicket, setLatestMintedTicket] = useState<PredictionTicket | null>(null);

  // Modal visibility states
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isHowItWorksOpen, setIsHowItWorksOpen] = useState(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [isTicketSuccessOpen, setIsTicketSuccessOpen] = useState(false);
  const [isExplorerOpen, setIsExplorerOpen] = useState(false);

  // Navigation handlers
  const handleStartPlaying = () => {
    setCurrentView('pools');
  };

  const handleSelectAsset = (asset: AssetSymbol) => {
    setSelectedAsset(asset);
    setCurrentView('pools');
  };

  const handleSelectPool = (pool: Pool) => {
    setSelectedPool(pool);
    setCurrentView('predict');
  };

  const handleSubmitPrediction = (predictedPrice: number) => {
    // Deduct entry fee
    setBalanceUsdc((prev) => Math.max(0, prev - 1));
    setUserPrediction(predictedPrice);

    // Create unique NFT ticket
    const newTicket: PredictionTicket = {
      id: `ticket-${Date.now()}`,
      poolId: selectedPool.id,
      asset: selectedPool.asset,
      period: selectedPool.period,
      direction: selectedPool.direction,
      predictedPrice,
      entryFee: 1,
      createdAt: 'Just now',
      nftTokenId: `${Math.floor(1000 + Math.random() * 9000)}`,
      txHash: `0x${Math.random().toString(16).substring(2, 10)}...${Math.random().toString(16).substring(2, 6)}`,
    };

    setTickets((prev) => [newTicket, ...prev]);
    setLatestMintedTicket(newTicket);
    setIsTicketSuccessOpen(true);

    // Update pool player count
    setPools((prev) =>
      prev.map((p) =>
        p.id === selectedPool.id
          ? { ...p, playersCount: p.playersCount + 1, poolSizeUsdc: p.poolSizeUsdc + 1 }
          : p
      )
    );
  };

  const handleClaimSuccess = (amount: number) => {
    setBalanceUsdc((prev) => prev + amount);
  };

  const isDarkNavbar = currentView === 'live';

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${
      currentView === 'live' ? 'bg-[#070A0F]' : 'bg-[#F6F6F8]'
    }`}>
      {/* Top Main Navbar & 5-Pages Quick Bar */}
      <Navbar
        currentView={currentView}
        onSelectView={(view) => setCurrentView(view)}
        walletAddress={walletAddress}
        onOpenWalletModal={() => setIsWalletModalOpen(true)}
        onOpenHowItWorks={() => setIsHowItWorksOpen(true)}
        onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
        isDarkTheme={isDarkNavbar}
      />

      {/* Main View Renderer based on selected page */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomepageView
            onStartPlaying={handleStartPlaying}
            onSelectAsset={handleSelectAsset}
          />
        )}

        {currentView === 'pools' && (
          <PoolsOverviewView
            pools={pools}
            selectedAsset={selectedAsset}
            onSelectAsset={setSelectedAsset}
            onSelectPool={handleSelectPool}
          />
        )}

        {currentView === 'predict' && (
          <MakePredictionView
            pool={selectedPool}
            onBack={() => setCurrentView('pools')}
            onSubmitPrediction={handleSubmitPrediction}
            walletConnected={!!walletAddress}
            onConnectWallet={() => setIsWalletModalOpen(true)}
          />
        )}

        {currentView === 'live' && (
          <LivePoolDetailsView
            pool={INITIAL_POOLS.find((p) => p.id === 'sol-daily-high') || selectedPool}
            userPrediction={userPrediction}
            onGoToResults={() => setCurrentView('results')}
            onOpenExplorer={() => setIsExplorerOpen(true)}
          />
        )}

        {currentView === 'results' && (
          <ResultsClaimView
            onBackToPools={() => setCurrentView('pools')}
            onOpenExplorer={() => setIsExplorerOpen(true)}
            onClaimSuccess={handleClaimSuccess}
          />
        )}
      </main>

      {/* Global Modals */}
      <WalletModal
        isOpen={isWalletModalOpen}
        onClose={() => setIsWalletModalOpen(false)}
        address={walletAddress || '0x3af4...92E1'}
        balanceUsdc={balanceUsdc}
        onAddFunds={(amt) => setBalanceUsdc((prev) => prev + amt)}
        onDisconnect={() => {
          setWalletAddress(null);
          setIsWalletModalOpen(false);
        }}
        tickets={tickets}
      />

      <HowItWorksModal
        isOpen={isHowItWorksOpen}
        onClose={() => setIsHowItWorksOpen(false)}
        onStartPlaying={() => {
          setIsHowItWorksOpen(false);
          setCurrentView('pools');
        }}
      />

      <LeaderboardModal
        isOpen={isLeaderboardOpen}
        onClose={() => setIsLeaderboardOpen(false)}
      />

      <TicketMintSuccessModal
        ticket={latestMintedTicket}
        isOpen={isTicketSuccessOpen}
        onClose={() => setIsTicketSuccessOpen(false)}
        onViewLivePool={() => {
          setIsTicketSuccessOpen(false);
          setCurrentView('live');
        }}
      />

      <ExplorerModal
        isOpen={isExplorerOpen}
        onClose={() => setIsExplorerOpen(false)}
      />
    </div>
  );
}
