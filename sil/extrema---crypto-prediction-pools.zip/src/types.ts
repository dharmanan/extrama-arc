export type AssetSymbol = 'BTC' | 'ETH' | 'SOL' | 'HYPE';
export type PoolPeriod = 'Daily' | 'Weekly' | 'Quarterly';
export type PredictionDirection = 'High' | 'Low';

export type AppView = 'home' | 'pools' | 'predict' | 'live' | 'results';

export interface Pool {
  id: string;
  asset: AssetSymbol;
  period: PoolPeriod;
  direction: PredictionDirection;
  title: string;
  description: string;
  currentPrice: number;
  formattedCurrentPrice: string;
  playersCount: number;
  poolSizeUsdc: number;
  sparklineData: number[];
  color: 'orange' | 'blue' | 'purple' | 'green' | 'cyan';
  roundId: string;
  endsAt: string;
  priceSource: string;
  suggestedPredictions: number[];
  histogramData?: { rangeLabel: string; min: number; max: number; count: number }[];
  minPrediction?: number;
  maxPrediction?: number;
}

export interface PredictionTicket {
  id: string;
  poolId: string;
  asset: AssetSymbol;
  direction: PredictionDirection;
  period: PoolPeriod;
  predictedPrice: number;
  entryFee: number;
  createdAt: string;
  nftTokenId: string;
  txHash: string;
}

export interface Winner {
  rank: number;
  address: string;
  predictedPrice: number;
  delta: number;
  prizeUsdc: number;
  prizePercentage: number;
  avatarBg: string;
  avatarSeed: string;
  isUser?: boolean;
}
